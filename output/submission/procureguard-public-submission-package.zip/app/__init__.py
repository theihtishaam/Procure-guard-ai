"""ProcureGuard AI application package."""

