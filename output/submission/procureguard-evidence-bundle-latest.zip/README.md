# ProcureGuard Evidence Bundle

This bundle contains the full run record, human-readable report, and audit manifest for one Band-style multi-agent workflow run.

- `run.json`: full structured run output.
- `report.md`: readable enterprise approval report.
- `audit-manifest.json`: summary of collaboration score, task state, recruitment ledger, business impact, governance controls, challenge review, decision, human gate, and audit seal.
